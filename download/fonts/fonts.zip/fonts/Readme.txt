Copy and paste it to your system's "Fonts" directory. You can find this directory by two simple ways: 

Run
Start > Run > type "fonts" and click OK

Control Panel Fonts 
Start > Control Panel > Fonts